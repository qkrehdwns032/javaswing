import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.awt.BorderLayout;
import javax.swing.JTextPane;

public class Project {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Project window = new Project();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Project() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement statement = null;
	
	private void initialize() {

		frame = new JFrame();

		frame.setTitle("Chelsea");
		frame.setBounds(100, 100, 673, 673);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);

		ImagePanel FirstPage = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		/*
		 * File f = new File("./Image/Chelsea.png");
		 * System.out.println(f.exists()?"Exxists":"Doesnt Exists");
		 */

		FirstPage.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(FirstPage);

		FirstPage.setVisible(true);

		JLabel Title = new JLabel("Chelsea");
		Title.setForeground(Color.blue);
		Title.setFont(new Font("Consolas", Font.BOLD, 35));
		Title.setHorizontalAlignment(SwingConstants.CENTER);
		Title.setBounds(95, 121, 481, 112);
		FirstPage.add(Title);

		JButton Matches = new JButton("Matches");
		Matches.setForeground(new Color(255, 128, 0));
		Matches.setFont(new Font("Consolas", Font.BOLD, 25));
		Matches.setHorizontalAlignment(SwingConstants.CENTER);
		Matches.setBounds(213, 220, 236, 59);
		FirstPage.add(Matches);

		JButton Players = new JButton("Players");
		Players.setForeground(new Color(255, 128, 0));
		Players.setFont(new Font("Consolas", Font.BOLD, 25));
		Players.setHorizontalAlignment(SwingConstants.CENTER);
		Players.setBounds(213, 300, 239, 54);
		FirstPage.add(Players);

		JButton Modification = new JButton("Modification");
		Modification.setFont(new Font("Consolas", Font.BOLD, 25));
		Modification.setForeground(new Color(255, 128, 0));
		Modification.setHorizontalAlignment(SwingConstants.CENTER);
		Modification.setBounds(213, 383, 238, 59);
		FirstPage.add(Modification);

		JButton EXIT = new JButton("EXIT");
		EXIT.setFont(new Font("Consolas", Font.BOLD, 20));
		EXIT.setBounds(512, 100, 91, 23);
		FirstPage.add(EXIT);

		EXIT.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		ImagePanel ToMatches = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToMatches.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(ToMatches);
		ToMatches.setLayout(null);

		JLabel Title1 = new JLabel("Chelsea");
		Title1.setFont(new Font("Consolas", Font.BOLD, 35));
		Title1.setForeground(new Color(0, 0, 255));
		Title1.setHorizontalAlignment(SwingConstants.CENTER);
		Title1.setBounds(139, 117, 389, 126);
		ToMatches.add(Title1);
		
		JButton Fixtures = new JButton("Fixtures");
		Fixtures.setFont(new Font("Consolas", Font.BOLD, 25));
		Fixtures.setForeground(new Color(255, 128, 0));
		Fixtures.setBounds(213, 220, 236, 59);
		ToMatches.add(Fixtures);

		JButton Results = new JButton("Results");
		Results.setForeground(new Color(255, 128, 0));
		Results.setFont(new Font("Consolas", Font.BOLD, 25));
		Results.setBounds(213, 300, 239, 54);
		ToMatches.add(Results);

		JButton LeagueTable = new JButton("LeagueTable");
		LeagueTable.setForeground(new Color(255, 128, 0));
		LeagueTable.setFont(new Font("Consolas", Font.BOLD, 25));
		LeagueTable.setBounds(213, 383, 238, 59);
		ToMatches.add(LeagueTable);

		JButton Home = new JButton("Home");
		Home.setFont(new Font("Consolas", Font.BOLD, 25));
		Home.setBounds(512, 100, 91, 23);
		ToMatches.add(Home);
		ToMatches.setVisible(false);

		Matches.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FirstPage.setVisible(false);
				ToMatches.setVisible(true);

			}
		});

		Home.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FirstPage.setVisible(true);
				ToMatches.setVisible(false);
			}
		});

		ImagePanel ToPlayer = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToPlayer.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(ToPlayer);
		ToPlayer.setLayout(null);

		JLabel Title2 = new JLabel("Chelsea");
		Title2.setHorizontalAlignment(SwingConstants.CENTER);
		Title2.setForeground(Color.BLUE);
		Title2.setFont(new Font("Consolas", Font.BOLD, 35));
		Title2.setBounds(139, 117, 389, 126);
		ToPlayer.add(Title2);

		JButton Players1 = new JButton("Players");
		Players1.setFont(new Font("Consolas", Font.BOLD, 25));
		Players1.setForeground(new Color(255, 128, 0));
		Players1.setBounds(213, 220, 236, 59);
		ToPlayer.add(Players1);

		JButton PlayersOnLoan = new JButton("Players On Loan");
		PlayersOnLoan.setFont(new Font("Consolas", Font.BOLD, 25));
		PlayersOnLoan.setForeground(new Color(255, 128, 0));
		PlayersOnLoan.setBounds(213, 300, 239, 54);
		ToPlayer.add(PlayersOnLoan);

		JButton HeadCoach = new JButton("Head Coach");
		HeadCoach.setFont(new Font("Consolas", Font.BOLD, 25));
		HeadCoach.setForeground(new Color(255, 128, 0));
		HeadCoach.setBounds(213, 383, 238, 59);
		ToPlayer.add(HeadCoach);

		JButton Home1 = new JButton("Home");
		Home1.setFont(new Font("Consolas", Font.BOLD, 25));
		Home1.setBounds(512, 100, 91, 23);
		ToPlayer.add(Home1);

		ToPlayer.setVisible(false);

		Players.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FirstPage.setVisible(false);
				ToPlayer.setVisible(true);
			}
		});

		ImagePanel ToModification = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToModification.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(ToModification);
		ToModification.setLayout(null);

		JLabel Title3 = new JLabel("Chelsea");
		Title3.setFont(new Font("Consolas", Font.BOLD, 35));
		Title3.setForeground(new Color(0, 0, 255));
		Title3.setHorizontalAlignment(SwingConstants.CENTER);
		Title3.setBounds(139, 117, 389, 126);
		ToModification.add(Title3);

		JButton Add = new JButton("ADD");
		Add.setFont(new Font("Consolas", Font.BOLD, 25));
		Add.setForeground(new Color(255, 128, 0));
		Add.setBounds(213, 245, 236, 59);
		ToModification.add(Add);

		JButton Delete = new JButton("Delete");
		Delete.setFont(new Font("Consolas", Font.BOLD, 25));
		Delete.setForeground(new Color(255, 128, 0));
		Delete.setBounds(213, 330, 239, 59);
		ToModification.add(Delete);

		JButton Home2 = new JButton("Home");
		Home2.setFont(new Font("Consolas", Font.BOLD, 25));
		Home2.setBounds(512, 100, 91, 23);
		ToModification.add(Home2);

		ToModification.setVisible(false);

		Modification.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FirstPage.setVisible(false);
				ToMatches.setVisible(false);
				ToPlayer.setVisible(false);
				ToModification.setVisible(true);
			}
		});

		Home2.setVisible(true);

		Home2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToModification.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		ImagePanel ToPlayers1 = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToPlayers1.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(ToPlayers1);
		ToPlayers1.setLayout(null);
		ToPlayers1.setVisible(false);

		JButton Home3 = new JButton("HOME");
		Home3.setFont(new Font("Consolas", Font.BOLD, 25));
		Home3.setBounds(512, 70, 91, 23);
		ToPlayers1.add(Home3);

		Home3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToPlayers1.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		Players1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					stmt = conn.createStatement();
					rs = stmt.executeQuery("SELECT * FROM player");

					DefaultTableModel tableModel = new DefaultTableModel();
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();

					for (int i = 1; i <= columnCount; i++) {
						tableModel.addColumn(metaData.getColumnName(i));
					}

					while (rs.next()) {
						Object[] rowData = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							rowData[i - 1] = rs.getObject(i);
						}
						tableModel.addRow(rowData);
					}

					JTable table = new JTable(tableModel);
					table.setPreferredScrollableViewportSize(new Dimension(500, 500));
					table.setFillsViewportHeight(true);
					table.setBackground(Color.cyan);

					DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
					renderer.setForeground(Color.blue);
					table.setDefaultRenderer(Object.class, renderer);

					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setPreferredSize(new Dimension(500, 500));
					scrollPane.setBounds(50, 100, 550, 500);
					
					ToPlayers1.add(scrollPane);

					ToPlayer.setVisible(false);
					ToPlayers1.setVisible(true);

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});

		Home1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToPlayer.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		ImagePanel ToLoan = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToLoan.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(ToLoan);
		ToLoan.setLayout(null);
		ToLoan.setVisible(false);

		JButton Home5 = new JButton("HOME");
		Home5.setFont(new Font("Consolas", Font.BOLD, 25));
		Home5.setBounds(512, 70, 91, 23);
		ToLoan.add(Home5);

		Home5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToLoan.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		PlayersOnLoan.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					stmt = conn.createStatement();
					rs = stmt.executeQuery("SELECT * FROM Loan");

					DefaultTableModel tableModel = new DefaultTableModel();
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();

					for (int i = 1; i <= columnCount; i++) {
						tableModel.addColumn(metaData.getColumnName(i));
					}
					
					while (rs.next()) {
						Object[] rowData = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							rowData[i - 1] = rs.getObject(i);
						}
						tableModel.addRow(rowData);
					}
					
					JTable table = new JTable(tableModel);
					table.setPreferredScrollableViewportSize(new Dimension(500, 500));
					table.setFillsViewportHeight(true);
					table.setBackground(Color.cyan);

					DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
					renderer.setForeground(Color.blue);
					table.setDefaultRenderer(Object.class, renderer);

					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setPreferredSize(new Dimension(500, 500));
					scrollPane.setBounds(50, 100, 550, 500);
					
					ToLoan.add(scrollPane);

					ToPlayer.setVisible(false);
					ToLoan.setVisible(true);

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToCoach = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToCoach.setBounds(0, 0, 673, 673);
		frame.getContentPane().add(ToCoach);
		ToCoach.setLayout(null);
		ToCoach.setVisible(false);

		JButton Home6 = new JButton("HOME");
		Home6.setFont(new Font("Consolas", Font.BOLD, 25));
		Home6.setBounds(512, 70, 91, 23);
		ToCoach.add(Home6);

		Home6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToCoach.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		HeadCoach.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					stmt = conn.createStatement();
					rs = stmt.executeQuery("SELECT * FROM Coach");

					DefaultTableModel tableModel = new DefaultTableModel();
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();

					for (int i = 1; i <= columnCount; i++) {
						tableModel.addColumn(metaData.getColumnName(i));
					}

					while (rs.next()) {
						Object[] rowData = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							rowData[i - 1] = rs.getObject(i);
						}
						tableModel.addRow(rowData);
					}

					JTable table = new JTable(tableModel);
					table.setPreferredScrollableViewportSize(new Dimension(500, 500));
					table.setFillsViewportHeight(true);
					table.setBackground(Color.cyan);

					DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
					renderer.setForeground(Color.blue);
					table.setDefaultRenderer(Object.class, renderer);

					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setPreferredSize(new Dimension(500, 37));

					scrollPane.setBounds(50, 100, 550, 37);
					ToCoach.add(scrollPane);
					
					ImagePanel Face = new ImagePanel
							(new ImageIcon("./Image/Face.jpg").getImage());
					Face.setBounds(50, 200, 550, 300);
					ToCoach.add(Face);
					Face.setLayout(null);

					ToPlayer.setVisible(false);
					ToCoach.setVisible(true);

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		ImagePanel ToFixtures = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToFixtures.setBounds(0, 0, 673, 673); // 일정보기 판넬
		frame.getContentPane().add(ToFixtures);
		ToFixtures.setLayout(null);
		ToFixtures.setVisible(false);
		
		JButton Home7 = new JButton("HOME");
		Home7.setFont(new Font("Consolas", Font.BOLD, 25));
		Home7.setBounds(512, 70, 91, 23);
		ToFixtures.add(Home7);

		Home7.addActionListener(new ActionListener() { // 일정보기 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToFixtures.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		Fixtures.addActionListener(new ActionListener() { // 일정보기버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					stmt = conn.createStatement();
					rs = stmt.executeQuery("SELECT * FROM Fixtures");

					DefaultTableModel tableModel = new DefaultTableModel();
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();

					for (int i = 1; i <= columnCount; i++) {
						tableModel.addColumn(metaData.getColumnName(i));
					}
					
					while (rs.next()) {
						Object[] rowData = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							rowData[i - 1] = rs.getObject(i);
						}
						tableModel.addRow(rowData);
					}

					JTable table = new JTable(tableModel);
					table.setPreferredScrollableViewportSize(new Dimension(500, 500));
					table.setFillsViewportHeight(true);
					table.setBackground(Color.cyan);

					DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
					renderer.setForeground(Color.blue);
					table.setDefaultRenderer(Object.class, renderer);

					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setPreferredSize(new Dimension(500, 500));
					
					scrollPane.setBounds(50, 100, 550,500);
					ToFixtures.add(scrollPane);

					ToMatches.setVisible(false);
					ToFixtures.setVisible(true);

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToResult = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToResult.setBounds(0, 0, 673, 673); // 결과보기 판넬
		frame.getContentPane().add(ToResult);
		ToResult.setLayout(null);
		ToResult.setVisible(false);

		JButton Home4 = new JButton("HOME");
		Home4.setFont(new Font("Consolas", Font.BOLD, 25));
		Home4.setBounds(512, 70, 91, 23);
		ToResult.add(Home4);

		Home4.addActionListener(new ActionListener() { // 결과보기 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToResult.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		Results.addActionListener(new ActionListener() { // 일정보기버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					stmt = conn.createStatement();
					rs = stmt.executeQuery("SELECT * FROM result");

					DefaultTableModel tableModel = new DefaultTableModel();
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();

					for (int i = 1; i <= columnCount; i++) {
						tableModel.addColumn(metaData.getColumnName(i));
					}
					
					while (rs.next()) {
						Object[] rowData = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							rowData[i - 1] = rs.getObject(i);
						}
						tableModel.addRow(rowData);
					}

					JTable table = new JTable(tableModel);
					table.setPreferredScrollableViewportSize(new Dimension(500, 500));
					table.setFillsViewportHeight(true);
					table.setBackground(Color.cyan);

					DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
					renderer.setForeground(Color.blue);
					table.setDefaultRenderer(Object.class, renderer);

					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setPreferredSize(new Dimension(500, 500));
					
					scrollPane.setBounds(50, 100, 550, 500);
					ToResult.add(scrollPane);

					ToMatches.setVisible(false);
					ToResult.setVisible(true);

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToLeagueTable = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToLeagueTable.setBounds(0, 0, 673, 673); // 리그 테이블 판넬
		frame.getContentPane().add(ToLeagueTable);
		ToLeagueTable.setLayout(null);
		ToLeagueTable.setVisible(false);

		JButton Home8 = new JButton("HOME");
		Home8.setFont(new Font("Consolas", Font.BOLD, 25));
		Home8.setBounds(512, 70, 91, 23);
		ToLeagueTable.add(Home8);

		Home8.addActionListener(new ActionListener() { // 리그테이블 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToLeagueTable.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		LeagueTable.addActionListener(new ActionListener() { // 리그 테이블 버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					stmt = conn.createStatement();
					rs = stmt.executeQuery("SELECT * FROM League");

					DefaultTableModel tableModel = new DefaultTableModel();
					ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

					int columnCount = metaData.getColumnCount();

					for (int i = 1; i <= columnCount; i++) {
						tableModel.addColumn(metaData.getColumnName(i));
					}
					
					while (rs.next()) {
						Object[] rowData = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							rowData[i - 1] = rs.getObject(i);
						}
						tableModel.addRow(rowData);
					}

					JTable table = new JTable(tableModel);
					table.setPreferredScrollableViewportSize(new Dimension(500, 500));
					table.setFillsViewportHeight(true);
					table.setBackground(Color.cyan);

					DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
					renderer.setForeground(Color.blue);
					table.setDefaultRenderer(Object.class, renderer);

					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setPreferredSize(new Dimension(500, 500));
					
					scrollPane.setBounds(50, 100, 550, 500);
					ToLeagueTable.add(scrollPane);
					
					ToMatches.setVisible(false);
					ToLeagueTable.setVisible(true);

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToAdd = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAdd.setBounds(0, 0, 673, 673); // ADD 
		frame.getContentPane().add(ToAdd);
		ToAdd.setLayout(null);
		ToAdd.setVisible(false);
		
		JButton AddPlayers = new JButton("Add Players");
		AddPlayers.setForeground(new Color(255, 128, 0));
		AddPlayers.setFont(new Font("Consolas",Font.BOLD,25));
		AddPlayers.setBounds(200, 140, 279, 59);
		ToAdd.add(AddPlayers);
		
		JButton AddLoan = new JButton("Add Loan Players");
		AddLoan.setForeground(new Color(255, 128, 0));
		AddLoan.setFont(new Font("Consolas",Font.BOLD,25));
		AddLoan.setBounds(200, 220, 275, 59);
		ToAdd.add(AddLoan);
		
		JButton AddHeadCoach = new JButton("Add HeadCoach");
		AddHeadCoach.setForeground(new Color(255, 128, 0));
		AddHeadCoach.setFont(new Font("Consolas",Font.BOLD,25));
		AddHeadCoach.setBounds(200, 300, 275, 59);
		ToAdd.add(AddHeadCoach);
		
		JButton AddFixtures = new JButton("Add Fixtures");
		AddFixtures.setForeground(new Color(255, 128, 0));
		AddFixtures.setFont(new Font("Consolas",Font.BOLD,25));
		AddFixtures.setBounds(200, 380, 275, 59);
		ToAdd.add(AddFixtures);
		
		JButton AddResults = new JButton("Add Results");
		AddResults.setForeground(new Color(255, 128, 0));
		AddResults.setFont(new Font("Consolas",Font.BOLD,25));
		AddResults.setBounds(200, 460, 275, 59);
		ToAdd.add(AddResults);
		
		JButton AddLeagueTable = new JButton("Add LeagueTable");
		AddLeagueTable.setForeground(new Color(255, 128, 0));
		AddLeagueTable.setFont(new Font("Consolas",Font.BOLD,25));
		AddLeagueTable.setBounds(200, 540, 275, 59);
		ToAdd.add(AddLeagueTable);
		
		JButton Home9 = new JButton("HOME");
		Home9.setFont(new Font("Consolas", Font.BOLD, 25));
		Home9.setBounds(512, 70, 91, 23);
		ToAdd.add(Home9);

		Home9.addActionListener(new ActionListener() { // ToAdd 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		Add.addActionListener(new ActionListener() { //  ToAdd 버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ToAdd.setVisible(true);
				ToModification.setVisible(false);
			}
		});
		
		ImagePanel ToAddPlayers = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAddPlayers.setBounds(0, 0, 673, 673); // Add players 눌렀을 Panel
		frame.getContentPane().add(ToAddPlayers);
		ToAddPlayers.setVisible(false);
		ToAddPlayers.setLayout(null);
		
		JLabel name = new JLabel("name");
		name.setBounds(100, 113, 100, 67);
		name.setHorizontalAlignment(SwingConstants.CENTER);
		name.setForeground(new Color(0, 255, 64));
		name.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(name);
		
		JTextField TextName = new JTextField(25);
		TextName.setBounds(23,170,262,60);
		TextName.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(TextName);
		
		JLabel age = new JLabel("age");
		age.setBounds(100, 240, 100, 67);
		age.setHorizontalAlignment(SwingConstants.CENTER);
		age.setForeground(new Color(0, 255, 64));
		age.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(age);
		
		JTextField TextAge = new JTextField(25);
		TextAge.setBounds(23, 299, 267, 60);
		TextAge.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(TextAge);
		
		JLabel Country = new JLabel("Country");
		Country.setBounds(100, 369, 100, 67);
		Country.setHorizontalAlignment(SwingConstants.CENTER);
		Country.setForeground(new Color(0, 255, 64));
		Country.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(Country);
		
		JTextField TextCountry = new JTextField(25);
		TextCountry.setBounds(23, 429, 267, 60);
		TextCountry.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(TextCountry);
		
		JLabel Height = new JLabel("Height");
		Height.setBounds(437, 113, 100, 67);
		Height.setHorizontalAlignment(SwingConstants.CENTER);
		Height.setForeground(new Color(0, 255, 64));
		Height.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(Height);
		
		JTextField TextHeight = new JTextField(25);
		TextHeight.setBounds(353, 170, 267, 60);
		TextHeight.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(TextHeight);
		
		JLabel Position = new JLabel("Position");
		Position.setBounds(437, 240, 120, 67);
		Position.setHorizontalAlignment(SwingConstants.LEFT);
		Position.setForeground(new Color(0, 255, 64));
		Position.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(Position);
		
		JTextField TextPosition = new JTextField(25);
		TextPosition.setBounds(353, 299, 267, 60);
		TextPosition.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(TextPosition);
		
		JLabel Number = new JLabel("Number");
		Number.setBounds(437, 369, 100, 67);
		Number.setHorizontalAlignment(SwingConstants.LEFT);
		Number.setForeground(new Color(0, 255, 64));
		Number.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(Number);
		
		JTextField TextNumber = new JTextField(25);
		TextNumber.setBounds(353, 429, 267, 60);
		TextNumber.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddPlayers.add(TextNumber);
		
		JButton commit = new JButton("commit");
		commit.setBounds(500, 103, 120, 23);
		commit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddPlayers.add(commit);
		
		commit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = TextName.getText();
				String age = TextAge.getText();
				String country = TextCountry.getText();
				String height = TextHeight.getText();
				String position = TextPosition.getText();
				String number = TextNumber.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "INSERT INTO player(name,age,Country,Height,Position,Number) Values(?,?,?,?,?,?)";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,name);
					statement.setString(2,age);
					statement.setString(3,country);
					statement.setString(4,height);
					statement.setString(5,position);
					statement.setString(6,number);

					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						ImagePanel commitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						commitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(commitbutton);
						commitbutton.setLayout(null);
						commitbutton.setVisible(false);
						
						JButton Home11 = new JButton("HOME");
						Home11.setBounds(512, 70, 91, 23);
						Home11.setFont(new Font("Consolas", Font.BOLD, 25));
						commitbutton.add(Home11);

						JLabel alert = new JLabel("Complete");
						alert.setForeground(Color.RED);
						alert.setFont(new Font("Consolas", Font.BOLD, 60));
						alert.setHorizontalAlignment(SwingConstants.CENTER);
						alert.setBounds(95,240, 481, 112);
						commitbutton.add(alert);
						
						Home11.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								commitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToAddPlayers.setVisible(false);
						commitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		JButton Home10 = new JButton("HOME");
		Home10.setBounds(512, 70, 91, 23);
		Home10.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddPlayers.add(Home10);

		Home10.addActionListener(new ActionListener() { //  ToAddPlayers 홈버튼
			@Override
			public void actionPerformed(ActionEvent e) {
				ToAddPlayers.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		AddPlayers.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				ToAddPlayers.setVisible(true);
			}
		});
		
		ImagePanel ToAddLoanPlayer = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAddLoanPlayer.setBounds(0, 0, 673, 673); // Add Loan player 눌렀을 Panel
		frame.getContentPane().add(ToAddLoanPlayer);
		ToAddLoanPlayer.setVisible(false);
		ToAddLoanPlayer.setLayout(null);
		
		JLabel Loanname = new JLabel("name");
		Loanname.setBounds(100, 113, 100, 67);
		Loanname.setHorizontalAlignment(SwingConstants.CENTER);
		Loanname.setForeground(new Color(0, 255, 64));
		Loanname.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(Loanname);
		
		JTextField LoanTextName = new JTextField(25);
		LoanTextName.setBounds(23,170,262,60);
		LoanTextName.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanTextName);
		
		JLabel LoanAge = new JLabel("age");
		LoanAge.setBounds(100, 240, 100, 67);
		LoanAge.setHorizontalAlignment(SwingConstants.CENTER);
		LoanAge.setForeground(new Color(0, 255, 64));
		LoanAge.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanAge);
		
		JTextField LoanTextAge = new JTextField(25);
		LoanTextAge.setBounds(23, 299, 267, 60);
		LoanTextAge.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanTextAge);
		
		JLabel LoanCountry = new JLabel("Country");
		LoanCountry.setBounds(100, 369, 100, 67);
		LoanCountry.setHorizontalAlignment(SwingConstants.CENTER);
		LoanCountry.setForeground(new Color(0, 255, 64));
		LoanCountry.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanCountry);
		
		JTextField LoanTextCountry = new JTextField(25);
		LoanTextCountry.setBounds(23, 429, 267, 60);
		LoanTextCountry.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanTextCountry);
		
		JLabel LoanHeight = new JLabel("Height");
		LoanHeight.setBounds(437, 113, 100, 67);
		LoanHeight.setHorizontalAlignment(SwingConstants.CENTER);
		LoanHeight.setForeground(new Color(0, 255, 64));
		LoanHeight.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanHeight);
		
		JTextField LoanTextHeight = new JTextField(25);
		LoanTextHeight.setBounds(353, 170, 267, 60);
		LoanTextHeight.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanTextHeight);
		
		JLabel LoanPosition = new JLabel("Position");
		LoanPosition.setBounds(437, 240, 120, 67);
		LoanPosition.setHorizontalAlignment(SwingConstants.LEFT);
		LoanPosition.setForeground(new Color(0, 255, 64));
		LoanPosition.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanPosition);
		
		JTextField LoanTextPosition = new JTextField(25);
		LoanTextPosition.setBounds(353, 299, 267, 60);
		LoanTextPosition.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanTextPosition);
		
		JLabel LoanNumber = new JLabel("Number");
		LoanNumber.setBounds(437, 369, 100, 67);
		LoanNumber.setHorizontalAlignment(SwingConstants.LEFT);
		LoanNumber.setForeground(new Color(0, 255, 64));
		LoanNumber.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanNumber);
		
		JTextField LoanTextNumber = new JTextField(25);
		LoanTextNumber.setBounds(353, 429, 267, 60);
		LoanTextNumber.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLoanPlayer.add(LoanTextNumber);
		
		JButton Home15 = new JButton("HOME");
		Home15.setFont(new Font("Consolas", Font.BOLD, 25));
		Home15.setBounds(512, 70, 91, 23);
		ToAddLoanPlayer.add(Home15);

		Home15.addActionListener(new ActionListener() { // ToAddLoanPlayer 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAddLoanPlayer.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		JButton LoanCommit = new JButton("commit");
		LoanCommit.setBounds(500, 103, 120, 23);
		LoanCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddLoanPlayer.add(LoanCommit);
		
		AddLoan.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				ToAddLoanPlayer.setVisible(true);
			}
		});
		
		LoanCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) { // DB연결
				String name = LoanTextName.getText();
				String age = LoanTextAge.getText();
				String country = LoanTextCountry.getText();
				String height = LoanTextHeight.getText();
				String position = LoanTextPosition.getText();
				String number = LoanTextNumber.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "INSERT INTO Loan(name,age,Country,Height,Position,Number) Values(?,?,?,?,?,?)";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,name);
					statement.setString(2,age);
					statement.setString(3,country);
					statement.setString(4,height);
					statement.setString(5,position);
					statement.setString(6,number);

					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						ImagePanel commitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						commitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(commitbutton);
						commitbutton.setLayout(null);
						commitbutton.setVisible(false);
						
						JButton Home = new JButton("HOME");
						Home.setBounds(512, 70, 91, 23);
						Home.setFont(new Font("Consolas", Font.BOLD, 25));
						commitbutton.add(Home);

						JLabel alert = new JLabel("Complete");
						alert.setForeground(Color.RED);
						alert.setFont(new Font("Consolas", Font.BOLD, 60));
						alert.setHorizontalAlignment(SwingConstants.CENTER);
						alert.setBounds(95,240, 481, 112);
						commitbutton.add(alert);
						
						Home.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								commitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToAddLoanPlayer.setVisible(false);
						commitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToDelete = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDelete.setBounds(0, 0, 673, 673); // ADD 
		frame.getContentPane().add(ToDelete);
		ToDelete.setLayout(null);
		ToDelete.setVisible(false);
		
		JButton DeletePlayers = new JButton("Delete Players");
		DeletePlayers.setForeground(new Color(255, 128, 0));
		DeletePlayers.setFont(new Font("Consolas",Font.BOLD,25));
		DeletePlayers.setBounds(200, 140, 279, 59);
		ToDelete.add(DeletePlayers);
		
		JButton DeleteLoan = new JButton("Delete Loan Players");
		DeleteLoan.setForeground(new Color(255, 128, 0));
		DeleteLoan.setFont(new Font("Consolas",Font.BOLD,25));
		DeleteLoan.setBounds(190, 220, 300, 59);
		ToDelete.add(DeleteLoan);
		
		JButton DeleteHeadCoach = new JButton("Delete HeadCoach");
		DeleteHeadCoach.setForeground(new Color(255, 128, 0));
		DeleteHeadCoach.setFont(new Font("Consolas",Font.BOLD,25));
		DeleteHeadCoach.setBounds(200, 300, 275, 59);
		ToDelete.add(DeleteHeadCoach);
		
		JButton DeleteFixtures = new JButton("Delete Fixtures");
		DeleteFixtures.setForeground(new Color(255, 128, 0));
		DeleteFixtures.setFont(new Font("Consolas",Font.BOLD,25));
		DeleteFixtures.setBounds(200, 380, 275, 59);
		ToDelete.add(DeleteFixtures);
		
		JButton DeleteResults = new JButton("Delete Results");
		DeleteResults.setForeground(new Color(255, 128, 0));
		DeleteResults.setFont(new Font("Consolas",Font.BOLD,25));
		DeleteResults.setBounds(200, 460, 275, 59);
		ToDelete.add(DeleteResults);
		
		JButton DeleteLeagueTable = new JButton("Delete LeagueTable");
		DeleteLeagueTable.setForeground(new Color(255, 128, 0));
		DeleteLeagueTable.setFont(new Font("Consolas",Font.BOLD,25));
		DeleteLeagueTable.setBounds(195, 540, 285, 59);
		ToDelete.add(DeleteLeagueTable);
		
		JButton Home12 = new JButton("HOME");
		Home12.setFont(new Font("Consolas", Font.BOLD, 25));
		Home12.setBounds(512, 70, 91, 23);
		ToDelete.add(Home12);

		Home12.addActionListener(new ActionListener() { // ToAdd 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				FirstPage.setVisible(true);
			}
		});

		Delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToModification.setVisible(false);
				ToDelete.setVisible(true);
			}
		});
		
		ImagePanel ToDeletePlayers = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDeletePlayers.setBounds(0, 0, 673, 673); // Add players 눌렀을 Panel
		frame.getContentPane().add(ToDeletePlayers);
		ToDeletePlayers.setVisible(false);
		ToDeletePlayers.setLayout(null);
		
		JLabel DeleteName = new JLabel("name");
		DeleteName.setBounds(145, 216, 100, 67);
		DeleteName.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteName.setForeground(new Color(255, 0, 0));
		DeleteName.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeletePlayers.add(DeleteName);
		
		JTextField DeleteTextName = new JTextField(25);
		DeleteTextName.setBounds(341,219,262,60);
		DeleteTextName.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeletePlayers.add(DeleteTextName);
		
		JButton Deletecommit = new JButton("commit");
		Deletecommit.setBounds(500, 103, 120, 23);
		Deletecommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToDeletePlayers.add(Deletecommit);
		
		JButton Home13 = new JButton("HOME");
		Home13.setFont(new Font("Consolas", Font.BOLD, 25));
		Home13.setBounds(512, 70, 91, 23);
		ToDeletePlayers.add(Home13);

		Home13.addActionListener(new ActionListener() { // ToAdd 홈버튼

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDeletePlayers.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		DeletePlayers.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				ToDeletePlayers.setVisible(true);
			}
		});
		
		Deletecommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String name = DeleteTextName.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "DELETE FROM player WHERE name = ?";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,name);

					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						ImagePanel Deletecommitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						Deletecommitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(Deletecommitbutton);
						Deletecommitbutton.setLayout(null);
						Deletecommitbutton.setVisible(false);
						
						JButton Home14 = new JButton("HOME");
						Home14.setBounds(512, 70, 91, 23);
						Home14.setFont(new Font("Consolas", Font.BOLD, 25));
						Deletecommitbutton.add(Home14);

						JLabel Deletealert = new JLabel("Complete");
						Deletealert.setForeground(Color.RED);
						Deletealert.setFont(new Font("Consolas", Font.BOLD, 60));
						Deletealert.setHorizontalAlignment(SwingConstants.CENTER);
						Deletealert.setBounds(95,240, 481, 112);
						Deletecommitbutton.add(Deletealert);
						
						Home14.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								Deletecommitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToDeletePlayers.setVisible(false);
						Deletecommitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToDeleteLoanPlayers = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDeleteLoanPlayers.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToDeleteLoanPlayers);
		ToDeleteLoanPlayers.setVisible(false);
		ToDeleteLoanPlayers.setLayout(null);
		
		JLabel DeleteLName = new JLabel("name");
		DeleteLName.setBounds(145, 216, 100, 67);
		DeleteLName.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLName.setForeground(new Color(255, 0, 0));
		DeleteLName.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLoanPlayers.add(DeleteLName);
		
		JTextField DeleteLTextName = new JTextField(25);
		DeleteLTextName.setBounds(341,219,262,60);
		DeleteLTextName.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLoanPlayers.add(DeleteLTextName);
		
		JButton DeleteLoancommit = new JButton("commit");
		DeleteLoancommit.setBounds(500, 103, 120, 23);
		DeleteLoancommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToDeleteLoanPlayers.add(DeleteLoancommit);
		
		JButton DLHome = new JButton("HOME");
		DLHome.setFont(new Font("Consolas", Font.BOLD, 25));
		DLHome.setBounds(512, 70, 91, 23);
		ToDeleteLoanPlayers.add(DLHome);
		
		DeleteLoan.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				ToDeleteLoanPlayers.setVisible(true);
			}
		});
		
		DLHome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDeleteLoanPlayers.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		DeleteLoancommit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String name = DeleteLTextName.getText();

				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "DELETE FROM Loan WHERE name = ?";

					statement = conn.prepareStatement(query);

					statement.setString(1, name);

					int rowsInserted = statement.executeUpdate();

					if (rowsInserted > 0) {

						ImagePanel Deletecommitbutton = new ImagePanel(
								new ImageIcon("./Image/Chelsea1.png").getImage());
						Deletecommitbutton.setBounds(0, 0, 673, 673);
						frame.getContentPane().add(Deletecommitbutton);
						Deletecommitbutton.setLayout(null);
						Deletecommitbutton.setVisible(false);

						JButton Home14 = new JButton("HOME");
						Home14.setBounds(512, 70, 91, 23);
						Home14.setFont(new Font("Consolas", Font.BOLD, 25));
						Deletecommitbutton.add(Home14);

						JLabel Deletealert = new JLabel("Complete");
						Deletealert.setForeground(Color.RED);
						Deletealert.setFont(new Font("Consolas", Font.BOLD, 60));
						Deletealert.setHorizontalAlignment(SwingConstants.CENTER);
						Deletealert.setBounds(95, 240, 481, 112);
						Deletecommitbutton.add(Deletealert);

						Home14.addActionListener(new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								Deletecommitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});

						ToDeleteLoanPlayers.setVisible(false);
						Deletecommitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		});
		
		ImagePanel ToAddCoach = new ImagePanel // coach add
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAddCoach.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToAddCoach);
		ToAddCoach.setVisible(false);
		ToAddCoach.setLayout(null);
		
		JLabel AddName = new JLabel("name");
		AddName.setBounds(145, 216, 100, 67);
		AddName.setHorizontalAlignment(SwingConstants.CENTER);
		AddName.setForeground(new Color(0, 255, 0));
		AddName.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddCoach.add(AddName);
		
		JTextField AddCTextName = new JTextField(25);
		AddCTextName.setBounds(341,219,262,60);
		AddCTextName.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddCoach.add(AddCTextName);
		
		JLabel AddAge = new JLabel("age");
		AddAge.setBounds(145, 330, 100, 67);
		AddAge.setHorizontalAlignment(SwingConstants.CENTER);
		AddAge.setForeground(new Color(0, 255, 0));
		AddAge.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddCoach.add(AddAge);
		
		JTextField AddCTextAge = new JTextField(25);
		AddCTextAge.setBounds(341,330,262,60);
		AddCTextAge.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddCoach.add(AddCTextAge);
		
		JLabel AddCountry = new JLabel("Country");
		AddCountry.setBounds(145, 440, 100, 67);
		AddCountry.setHorizontalAlignment(SwingConstants.CENTER);
		AddCountry.setForeground(new Color(0, 255, 0));
		AddCountry.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddCoach.add(AddCountry);
		
		JTextField AddCTextCountry = new JTextField(25);
		AddCTextCountry.setBounds(341,440,262,60);
		AddCTextCountry.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddCoach.add(AddCTextCountry);
		
		JButton ACCommit = new JButton("commit");
		ACCommit.setBounds(500, 103, 120, 23);
		ACCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddCoach.add(ACCommit);
		
		JButton ACHome = new JButton("HOME");
		ACHome.setFont(new Font("Consolas", Font.BOLD, 25));
		ACHome.setBounds(512, 70, 91, 23);
		ToAddCoach.add(ACHome);
		
		AddHeadCoach.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				ToAddCoach.setVisible(true);
			}
		});
		
		ACHome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAddCoach.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		
		ACCommit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String name = AddCTextName.getText();
				String age = AddCTextAge.getText();
				String country = AddCTextCountry.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "INSERT INTO Coach(name,age,Country) Values(?,?,?)";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,name);
					statement.setString(2,age);
					statement.setString(3,country);
					
					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						ImagePanel commitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						commitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(commitbutton);
						commitbutton.setLayout(null);
						commitbutton.setVisible(false);
						
						JButton Home = new JButton("HOME");
						Home.setBounds(512, 70, 91, 23);
						Home.setFont(new Font("Consolas", Font.BOLD, 25));
						commitbutton.add(Home);

						JLabel alert = new JLabel("Complete");
						alert.setForeground(Color.RED);
						alert.setFont(new Font("Consolas", Font.BOLD, 60));
						alert.setHorizontalAlignment(SwingConstants.CENTER);
						alert.setBounds(95,240, 481, 112);
						commitbutton.add(alert);
						
						Home.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								commitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToAddCoach.setVisible(false);
						commitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
			}
		}); 
		
		ImagePanel ToDeleteCoach = new ImagePanel // coach Delete
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDeleteCoach.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToDeleteCoach);
		ToDeleteCoach.setVisible(false);
		ToDeleteCoach.setLayout(null);
		
		JLabel DeleteCName = new JLabel("name");
		DeleteCName.setBounds(145, 216, 100, 67);
		DeleteCName.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteCName.setForeground(new Color(255, 0, 0));
		DeleteCName.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteCoach.add(DeleteCName);
		
		JTextField DeleteCTextName = new JTextField(25);
		DeleteCTextName.setBounds(341,219,262,60);
		DeleteCTextName.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteCoach.add(DeleteCTextName);
		
		JButton DCCommit = new JButton("commit");
		DCCommit.setBounds(500, 103, 120, 23);
		DCCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToDeleteCoach.add(DCCommit);
		
		JButton DCHome = new JButton("HOME");
		DCHome.setFont(new Font("Consolas", Font.BOLD, 25));
		DCHome.setBounds(512, 70, 91, 23);
		ToDeleteCoach.add(DCHome);
		
		DCHome.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToDeleteCoach.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		DeleteHeadCoach.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				ToDeleteCoach.setVisible(true);
			}
		});
		
		DCCommit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String name = DeleteCTextName.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "DELETE FROM Coach WHERE name = ?";

					statement = conn.prepareStatement(query);

					statement.setString(1, name);

					int rowsInserted = statement.executeUpdate();

					if (rowsInserted > 0) {

						ImagePanel Deletecommitbutton = new ImagePanel(
								new ImageIcon("./Image/Chelsea1.png").getImage());
						Deletecommitbutton.setBounds(0, 0, 673, 673);
						frame.getContentPane().add(Deletecommitbutton);
						Deletecommitbutton.setLayout(null);
						Deletecommitbutton.setVisible(false);

						JButton Home14 = new JButton("HOME");
						Home14.setBounds(512, 70, 91, 23);
						Home14.setFont(new Font("Consolas", Font.BOLD, 25));
						Deletecommitbutton.add(Home14);

						JLabel Deletealert = new JLabel("Complete");
						Deletealert.setForeground(Color.RED);
						Deletealert.setFont(new Font("Consolas", Font.BOLD, 60));
						Deletealert.setHorizontalAlignment(SwingConstants.CENTER);
						Deletealert.setBounds(95, 240, 481, 112);
						Deletecommitbutton.add(Deletealert);

						Home14.addActionListener(new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								Deletecommitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});

						ToDeleteCoach.setVisible(false);
						Deletecommitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}

			}
		}); //Delete Coach 
		
		ImagePanel ToAddFixtures = new ImagePanel // Fixtures add
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAddFixtures.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToAddFixtures);
		ToAddFixtures.setVisible(false);
		ToAddFixtures.setLayout(null);
		
		JLabel AddDate = new JLabel("Date");
		AddDate.setBounds(145, 165, 100, 67);
		AddDate.setHorizontalAlignment(SwingConstants.CENTER);
		AddDate.setForeground(new Color(0, 255, 0));
		AddDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddDate);
		
		JTextField AddTextDate = new JTextField(25);
		AddTextDate.setBounds(341,168,262,60);
		AddTextDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddTextDate);
		
		JLabel AddType = new JLabel("Type");
		AddType.setBounds(145, 256, 100, 67);
		AddType.setHorizontalAlignment(SwingConstants.CENTER);
		AddType.setForeground(new Color(0, 255, 0));
		AddType.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddType);
		
		JTextField AddTextType = new JTextField(50);
		AddTextType.setBounds(341,256,262,60);
		AddTextType.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddTextType);
		
		JLabel AddTime = new JLabel("Time");
		AddTime.setBounds(145, 336, 100, 67);
		AddTime.setHorizontalAlignment(SwingConstants.CENTER);
		AddTime.setForeground(new Color(0, 255, 0));
		AddTime.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddTime);
		
		JTextField AddTextTime = new JTextField(50);
		AddTextTime.setBounds(341,339,262,60);
		AddTextTime.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddTextTime);
		
		JLabel AddVS = new JLabel("VS");
		AddVS.setBounds(145, 413, 100, 67);
		AddVS.setHorizontalAlignment(SwingConstants.CENTER);
		AddVS.setForeground(new Color(0, 255, 0));
		AddVS.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddVS);
		
		JTextField AddTextVS = new JTextField(50);
		AddTextVS.setBounds(341,409,262,60);
		AddTextVS.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddFixtures.add(AddTextVS);
		
		JButton AFCommit = new JButton("commit");
		AFCommit.setBounds(500, 103, 120, 23);
		AFCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddFixtures.add(AFCommit);
		
		JButton AFHome = new JButton("HOME");
		AFHome.setFont(new Font("Consolas", Font.BOLD, 25));
		AFHome.setBounds(512, 70, 91, 23);
		ToAddFixtures.add(AFHome);
		
		AddFixtures.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				ToAddFixtures.setVisible(true);
			}
			
		});
		
		AFHome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAddFixtures.setVisible(false);
				FirstPage.setVisible(true);
			}
			
		});
		
		AFCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String Date = AddTextDate.getText();
				String Type = AddTextType.getText();
				String Time = AddTextTime.getText();
				String VS = AddTextVS.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "INSERT INTO Fixtures(Date,Type,Time,VS)Values(?,?,?,?)";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,Date);
					statement.setString(2,Type);
					statement.setString(3,Time);
					statement.setString(4,VS);
					
					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						ImagePanel commitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						commitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(commitbutton);
						commitbutton.setLayout(null);
						commitbutton.setVisible(false);
						
						JButton Home = new JButton("HOME");
						Home.setBounds(512, 70, 91, 23);
						Home.setFont(new Font("Consolas", Font.BOLD, 25));
						commitbutton.add(Home);

						JLabel alert = new JLabel("Complete");
						alert.setForeground(Color.RED);
						alert.setFont(new Font("Consolas", Font.BOLD, 60));
						alert.setHorizontalAlignment(SwingConstants.CENTER);
						alert.setBounds(95,240, 481, 112);
						commitbutton.add(alert);
						
						Home.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								commitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToAddFixtures.setVisible(false);
						commitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
						
			}
			
		}); // Add Fixtures
		
		ImagePanel ToDeleteFixtures = new ImagePanel // Fixtures Delete
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDeleteFixtures.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToDeleteFixtures);
		ToDeleteFixtures.setVisible(false);
		ToDeleteFixtures.setLayout(null);
		
		JLabel DeleteFDate = new JLabel("Date");
		DeleteFDate.setBounds(145, 216, 100, 67);
		DeleteFDate.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteFDate.setForeground(new Color(255, 0, 0));
		DeleteFDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteFixtures.add(DeleteFDate);
		
		JTextField DeleteFTextDate = new JTextField(25);
		DeleteFTextDate.setBounds(341,219,262,60);
		DeleteFTextDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteFixtures.add(DeleteFTextDate);
		
		JLabel DeleteFVS = new JLabel("VS");
		DeleteFVS.setBounds(145, 333, 100, 67);
		DeleteFVS.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteFVS.setForeground(new Color(255, 0, 0));
		DeleteFVS.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteFixtures.add(DeleteFVS);
		
		JTextField DeleteFTextVS = new JTextField(25);
		DeleteFTextVS.setBounds(341,336,262,60);
		DeleteFTextVS.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteFixtures.add(DeleteFTextVS);
		
		JButton DFCommit = new JButton("commit");
		DFCommit.setBounds(500, 103, 120, 23);
		DFCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToDeleteFixtures.add(DFCommit);
		
		JButton DFHome = new JButton("HOME");
		DFHome.setFont(new Font("Consolas", Font.BOLD, 25));
		DFHome.setBounds(512, 70, 91, 23);
		ToDeleteFixtures.add(DFHome);
		
		DeleteFixtures.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				ToDeleteFixtures.setVisible(true);
			}
			
		});
		
		DFHome.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToDeleteFixtures.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		DFCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String Date = DeleteFTextDate.getText();
				String VS = DeleteFTextVS.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "DELETE FROM Fixtures WHERE Date = ? and VS = ?";

					statement = conn.prepareStatement(query);

					statement.setString(1, Date);
					statement.setString(2, VS);

					int rowsInserted = statement.executeUpdate();

					if (rowsInserted > 0) {

						ImagePanel Deletecommitbutton = new ImagePanel(
								new ImageIcon("./Image/Chelsea1.png").getImage());
						Deletecommitbutton.setBounds(0, 0, 673, 673);
						frame.getContentPane().add(Deletecommitbutton);
						Deletecommitbutton.setLayout(null);
						Deletecommitbutton.setVisible(false);

						JButton Home14 = new JButton("HOME");
						Home14.setBounds(512, 70, 91, 23);
						Home14.setFont(new Font("Consolas", Font.BOLD, 25));
						Deletecommitbutton.add(Home14);

						JLabel Deletealert = new JLabel("Complete");
						Deletealert.setForeground(Color.RED);
						Deletealert.setFont(new Font("Consolas", Font.BOLD, 60));
						Deletealert.setHorizontalAlignment(SwingConstants.CENTER);
						Deletealert.setBounds(95, 240, 481, 112);
						Deletecommitbutton.add(Deletealert);

						Home14.addActionListener(new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								Deletecommitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});

						ToDeleteFixtures.setVisible(false);
						Deletecommitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
				
			}
			
		}); // Delete Fixtures
		
		ImagePanel ToAddResults = new ImagePanel // Results add
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAddResults.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToAddResults);
		ToAddResults.setVisible(false);
		ToAddResults.setLayout(null);
		
		JLabel AddRDate = new JLabel("Date");
		AddRDate.setBounds(100, 113, 100, 67);
		AddRDate.setHorizontalAlignment(SwingConstants.CENTER);
		AddRDate.setForeground(new Color(0, 255, 0));
		AddRDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRDate);
		
		JTextField AddRTextDate = new JTextField(25);
		AddRTextDate.setBounds(23,170,262,60);
		AddRTextDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRTextDate);
		
		JLabel AddRType = new JLabel("Type");
		AddRType.setBounds(100, 240, 100, 67);
		AddRType.setHorizontalAlignment(SwingConstants.CENTER);
		AddRType.setForeground(new Color(0, 255, 0));
		AddRType.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRType);
		
		JTextField AddRTextType = new JTextField(50);
		AddRTextType.setBounds(23,299,262,60);
		AddRTextType.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRTextType);
		
		JLabel AddRWin = new JLabel("Win");
		AddRWin.setBounds(100, 369, 100, 67);
		AddRWin.setHorizontalAlignment(SwingConstants.CENTER);
		AddRWin.setForeground(new Color(0, 255, 0));
		AddRWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRWin);
		
		JTextField AddRTextWin = new JTextField(50);
		AddRTextWin.setBounds(23,429,262,60);
		AddRTextWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRTextWin);
		
		JLabel AddRLose = new JLabel("Lose");
		AddRLose.setBounds(437, 113, 100, 67);
		AddRLose.setHorizontalAlignment(SwingConstants.CENTER);
		AddRLose.setForeground(new Color(0, 255, 0));
		AddRLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRLose);
		
		JTextField AddRTextLose = new JTextField(50);
		AddRTextLose.setBounds(353,170,267,60);
		AddRTextLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRTextLose);
		
		JLabel AddRDraw = new JLabel("Draw");
		AddRDraw.setBounds(437, 240, 120, 67);
		AddRDraw.setHorizontalAlignment(SwingConstants.CENTER);
		AddRDraw.setForeground(new Color(0, 255, 0));
		AddRDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRDraw);
		
		JTextField AddRTextDraw = new JTextField(50);
		AddRTextDraw.setBounds(353,299,267,60);
		AddRTextDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRTextDraw);
		
		JLabel AddRScore = new JLabel("Score");
		AddRScore.setBounds(437, 369, 100, 67);
		AddRScore.setHorizontalAlignment(SwingConstants.CENTER);
		AddRScore.setForeground(new Color(0, 255, 0));
		AddRScore.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRScore);
		
		JTextField AddRTextScore = new JTextField(50);
		AddRTextScore.setBounds(353,429,267,60);
		AddRTextScore.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddResults.add(AddRTextScore);
		
		AddResults.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				ToAddResults.setVisible(true);
			}
			
		});
		
		JButton ARCommit = new JButton("commit");
		ARCommit.setBounds(500, 103, 120, 23);
		ARCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddResults.add(ARCommit);
		
		JButton ARHome = new JButton("HOME");
		ARHome.setFont(new Font("Consolas", Font.BOLD, 25));
		ARHome.setBounds(512, 70, 91, 23);
		ToAddResults.add(ARHome);
		
		ARHome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAddResults.setVisible(false);
				FirstPage.setVisible(true);
			}
			
		});
		
		ARCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String Date = AddRTextDate.getText();
			    String Type = AddRTextType.getText();
			    String Win = AddRTextWin.getText();
			    String Lose = AddRTextLose.getText();
			    String Draw = AddRTextDraw.getText();
			    String Score = AddRTextScore.getText();
			    
			    try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "INSERT INTO result(Date,Type,Win,Lose,Draw,Score)Values(?,?,?,?,?,?)";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,Date);
					statement.setString(2,Type);
					statement.setString(3,Win);
					statement.setString(4,Lose);
					statement.setString(5,Draw);
					statement.setString(6,Score);
					
					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						System.out.println(111);
						ImagePanel commitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						commitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(commitbutton);
						commitbutton.setLayout(null);
						commitbutton.setVisible(false);
						
						JButton Home = new JButton("HOME");
						Home.setBounds(512, 70, 91, 23);
						Home.setFont(new Font("Consolas", Font.BOLD, 25));
						commitbutton.add(Home);

						JLabel alert = new JLabel("Complete");
						alert.setForeground(Color.RED);
						alert.setFont(new Font("Consolas", Font.BOLD, 60));
						alert.setHorizontalAlignment(SwingConstants.CENTER);
						alert.setBounds(95,240, 481, 112);
						commitbutton.add(alert);
						
						Home.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								commitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToAddResults.setVisible(false);
						commitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
			}
			
		}); // Add Result
		
		ImagePanel ToDeleteResult = new ImagePanel // Result Delete
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDeleteResult.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToDeleteResult);
		ToDeleteResult.setVisible(false);
		ToDeleteResult.setLayout(null);
		
		JLabel DeleteRDate = new JLabel("Date");
		DeleteRDate.setBounds(100, 113, 100, 67);
		DeleteRDate.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteRDate.setForeground(new Color(255, 0, 0));
		DeleteRDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRDate);
		
		JTextField DeleteRTextDate = new JTextField(25);
		DeleteRTextDate.setBounds(23,170,262,60);
		DeleteRTextDate.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRTextDate);
		
		JLabel DeleteRType = new JLabel("Type");
		DeleteRType.setBounds(100, 240, 100, 67);
		DeleteRType.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteRType.setForeground(new Color(255, 0, 0));
		DeleteRType.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRType);
		
		JTextField DeleteRTextType = new JTextField(25);
		DeleteRTextType.setBounds(23,299,262,60);
		DeleteRTextType.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRTextType);
		
		JLabel DeleteRWin = new JLabel("Win");
		DeleteRWin.setBounds(100, 369, 100, 67);
		DeleteRWin.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteRWin.setForeground(new Color(255, 0, 0));
		DeleteRWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRWin);
		
		JTextField DeleteRTextWin = new JTextField(25);
		DeleteRTextWin.setBounds(23,429,262,60);
		DeleteRTextWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRTextWin);
		
		JLabel DeleteRLose = new JLabel("Lose");
		DeleteRLose.setBounds(437, 113, 100, 67);
		DeleteRLose.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteRLose.setForeground(new Color(255, 0, 0));
		DeleteRLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRLose);
		
		JTextField DeleteRTextLose = new JTextField(25);
		DeleteRTextLose.setBounds(353,170,267,60);
		DeleteRTextLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRTextLose);
		
		JLabel DeleteRDraw = new JLabel("Draw");
		DeleteRDraw.setBounds(437, 240, 120, 67);
		DeleteRDraw.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteRDraw.setForeground(new Color(255, 0, 0));
		DeleteRDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRDraw);
		
		JTextField DeleteRTextDraw = new JTextField(25);
		DeleteRTextDraw.setBounds(353,299,267,60);
		DeleteRTextDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRTextDraw);
		
		JLabel DeleteRScore = new JLabel("Score");
		DeleteRScore.setBounds(437, 369, 100, 67);
		DeleteRScore.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteRScore.setForeground(new Color(255, 0, 0));
		DeleteRScore.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRScore);
		
		JTextField DeleteRTexTScore = new JTextField(25);
		DeleteRTexTScore.setBounds(353,429,267,60);
		DeleteRTexTScore.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteResult.add(DeleteRTexTScore);
		
		JButton DRCommit = new JButton("commit");
		DRCommit.setBounds(500, 103, 120, 23);
		DRCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToDeleteResult.add(DRCommit);
		
		JButton DRHome = new JButton("HOME");
		DRHome.setFont(new Font("Consolas", Font.BOLD, 25));
		DRHome.setBounds(512, 70, 91, 23);
		ToDeleteResult.add(DRHome);
		
		DeleteResults.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				ToDeleteResult.setVisible(true);
			}
			
		});
		
		DRHome.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ToDeleteResult.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		DRCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String Date = DeleteRTextDate.getText();
				String Type = DeleteRTextType.getText();
				String Win = DeleteRTextWin.getText();
				String Lose = DeleteRTextLose.getText();
				String Draw = DeleteRTextDraw.getText();
				String Score = DeleteRTexTScore.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "DELETE FROM result WHERE Date = ? and Type = ? and Win = ? and Lose = ? and Draw = ? and Score = ?";

					statement = conn.prepareStatement(query);

					statement.setString(1, Date);
					statement.setString(2, Type);
					statement.setString(3, Win);
					statement.setString(4, Lose);
					statement.setString(5, Draw);
					statement.setString(6, Score);

					int rowsInserted = statement.executeUpdate();

					if (rowsInserted > 0) {

						ImagePanel Deletecommitbutton = new ImagePanel(
								new ImageIcon("./Image/Chelsea1.png").getImage());
						Deletecommitbutton.setBounds(0, 0, 673, 673);
						frame.getContentPane().add(Deletecommitbutton);
						Deletecommitbutton.setLayout(null);
						Deletecommitbutton.setVisible(false);

						JButton Home14 = new JButton("HOME");
						Home14.setBounds(512, 70, 91, 23);
						Home14.setFont(new Font("Consolas", Font.BOLD, 25));
						Deletecommitbutton.add(Home14);

						JLabel Deletealert = new JLabel("Complete");
						Deletealert.setForeground(Color.RED);
						Deletealert.setFont(new Font("Consolas", Font.BOLD, 60));
						Deletealert.setHorizontalAlignment(SwingConstants.CENTER);
						Deletealert.setBounds(95, 240, 481, 112);
						Deletecommitbutton.add(Deletealert);

						Home14.addActionListener(new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								Deletecommitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});

						ToDeleteResult.setVisible(false);
						Deletecommitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
			}
		}); // Delete result
		
		ImagePanel ToAddLeagueTable = new ImagePanel // LeagueTable add
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToAddLeagueTable.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToAddLeagueTable);
		ToAddLeagueTable.setVisible(false);
		ToAddLeagueTable.setLayout(null);
		
		JLabel AddLRanking = new JLabel("Ranking");
		AddLRanking.setBounds(100, 110, 100, 67);
		AddLRanking.setHorizontalAlignment(SwingConstants.CENTER);
		AddLRanking.setForeground(new Color(0, 255, 0));
		AddLRanking.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLRanking);
		
		JTextField AddLTextRanking = new JTextField(25);
		AddLTextRanking.setBounds(23,160,262,60);
		AddLTextRanking.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextRanking);
		
		JLabel AddLTeam = new JLabel("Team");
		AddLTeam.setBounds(100, 213, 100, 67);
		AddLTeam.setHorizontalAlignment(SwingConstants.CENTER);
		AddLTeam.setForeground(new Color(0, 255, 0));
		AddLTeam.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTeam);
		
		JTextField AddLTextTeam = new JTextField(25);
		AddLTextTeam.setBounds(23,270,262,60);
		AddLTextTeam.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextTeam);
		
		JLabel AddLPlay = new JLabel("Play");
		AddLPlay.setBounds(100, 340, 100, 67);
		AddLPlay.setHorizontalAlignment(SwingConstants.CENTER);
		AddLPlay.setForeground(new Color(0, 255, 0));
		AddLPlay.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLPlay);
		
		JTextField AddLTextPlay = new JTextField(50);
		AddLTextPlay.setBounds(23,399,262,60);
		AddLTextPlay.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextPlay);
		
		JLabel AddLWin = new JLabel("Win");
		AddLWin.setBounds(100, 469, 100, 67);
		AddLWin.setHorizontalAlignment(SwingConstants.CENTER);
		AddLWin.setForeground(new Color(0, 255, 0));
		AddLWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLWin);
		
		JTextField AddLTextWin = new JTextField(50);
		AddLTextWin.setBounds(23,529,262,60);
		AddLTextWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextWin);
		
		JLabel AddLDraw = new JLabel("Draw");
		AddLDraw.setBounds(437, 113, 100, 67);
		AddLDraw.setHorizontalAlignment(SwingConstants.CENTER);
		AddLDraw.setForeground(new Color(0, 255, 0));
		AddLDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLDraw);
		
		JTextField AddLTextDraw = new JTextField(50);
		AddLTextDraw.setBounds(353,170,267,60);
		AddLTextDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextDraw);
		
		JLabel AddLLose = new JLabel("Lose");
		AddLLose.setBounds(437, 240, 120, 67);
		AddLLose.setHorizontalAlignment(SwingConstants.CENTER);
		AddLLose.setForeground(new Color(0, 255, 0));
		AddLLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLLose);
		
		JTextField AddLTextLose = new JTextField(50);
		AddLTextLose.setBounds(353,299,267,60);
		AddLTextLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextLose);
		
		JLabel AddLGD = new JLabel("GD");
		AddLGD.setBounds(437, 369, 100, 67);
		AddLGD.setHorizontalAlignment(SwingConstants.CENTER);
		AddLGD.setForeground(new Color(0, 255, 0));
		AddLGD.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLGD);
		
		JTextField AddLTextGD = new JTextField(50);
		AddLTextGD.setBounds(353,429,267,60);
		AddLTextGD.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextGD);
		
		JLabel AddLPTS = new JLabel("PTS");
		AddLPTS.setBounds(437, 469, 100, 67);
		AddLPTS.setHorizontalAlignment(SwingConstants.CENTER);
		AddLPTS.setForeground(new Color(0, 255, 0));
		AddLPTS.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLPTS);
		
		JTextField AddLTextPTS = new JTextField(50);
		AddLTextPTS.setBounds(353,529,267,60);
		AddLTextPTS.setFont(new Font("Consolas",Font.BOLD,25));
		ToAddLeagueTable.add(AddLTextPTS);
		
		AddLeagueTable.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAdd.setVisible(false);
				ToAddLeagueTable.setVisible(true);
			}
			
		});
		
		JButton ALCommit = new JButton("commit");
		ALCommit.setBounds(500, 103, 120, 23);
		ALCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToAddLeagueTable.add(ALCommit);
		
		JButton ALHome = new JButton("HOME");
		ALHome.setFont(new Font("Consolas", Font.BOLD, 25));
		ALHome.setBounds(512, 70, 91, 23);
		ToAddLeagueTable.add(ALHome);
		
		ALHome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToAddLeagueTable.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		ALCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String Ranking = AddLTextRanking.getText();
				String Team = AddLTextTeam.getText();
				String Play = AddLTextPlay.getText();
				String Win = AddLTextWin.getText();
				String Draw = AddLTextDraw.getText();
				String Lose = AddLTextLose.getText();
				String GD = AddLTextGD.getText();
				String PTS = AddLTextPTS.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "INSERT INTO League(Ranking,Team,Play,Win,Draw,Lose,GD,PTS)Values(?,?,?,?,?,?,?,?)";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1,Ranking);
					statement.setString(2,Team);
					statement.setString(3,Play);
					statement.setString(4,Win);
					statement.setString(5,Draw);
					statement.setString(6,Lose);
					statement.setString(7,GD);
					statement.setString(8,PTS);
					
					int rowsInserted = statement.executeUpdate();
					
					if (rowsInserted > 0) {

						ImagePanel commitbutton = new ImagePanel(new ImageIcon("./Image/Chelsea1.png").getImage());
						commitbutton.setBounds(0, 0, 673, 673); 
						frame.getContentPane().add(commitbutton);
						commitbutton.setLayout(null);
						commitbutton.setVisible(false);
						
						JButton Home = new JButton("HOME");
						Home.setBounds(512, 70, 91, 23);
						Home.setFont(new Font("Consolas", Font.BOLD, 25));
						commitbutton.add(Home);

						JLabel alert = new JLabel("Complete");
						alert.setForeground(Color.RED);
						alert.setFont(new Font("Consolas", Font.BOLD, 60));
						alert.setHorizontalAlignment(SwingConstants.CENTER);
						alert.setBounds(95,240, 481, 112);
						commitbutton.add(alert);
						
						Home.addActionListener(new ActionListener() { 
							@Override
							public void actionPerformed(ActionEvent e) {
								commitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});
						
						ToAddLeagueTable.setVisible(false);
						commitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
			}
		}); // Add LeagueTable
		
		ImagePanel ToDeleteLeagueTable = new ImagePanel // LeagueTable Delete
				(new ImageIcon("./Image/Chelsea1.png").getImage());
		ToDeleteLeagueTable.setBounds(0, 0, 673, 673); 
		frame.getContentPane().add(ToDeleteLeagueTable);
		ToDeleteLeagueTable.setVisible(false);
		ToDeleteLeagueTable.setLayout(null);
		
		JLabel DeleteLRanking = new JLabel("Ranking");
		DeleteLRanking.setBounds(100, 113, 100, 67);
		DeleteLRanking.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLRanking.setForeground(new Color(255, 0, 0));
		DeleteLRanking.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLRanking);
		
		JTextField DeleteLTextRanking = new JTextField(25);
		DeleteLTextRanking.setBounds(23,170,262,60);
		DeleteLTextRanking.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextRanking);
		
		JLabel DeleteLTeam = new JLabel("Team");
		DeleteLTeam.setBounds(100, 240, 100, 67);
		DeleteLTeam.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLTeam.setForeground(new Color(255, 0, 0));
		DeleteLTeam.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTeam);
		
		JTextField DeleteLTextTeam = new JTextField(25);
		DeleteLTextTeam.setBounds(23,299,262,60);
		DeleteLTextTeam.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextTeam);
		
		JLabel DeleteLPlay = new JLabel("Play");
		DeleteLPlay.setBounds(100, 369, 100, 67);
		DeleteLPlay.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLPlay.setForeground(new Color(255, 0, 0));
		DeleteLPlay.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLPlay);
		
		JTextField DeleteLTextPlay = new JTextField(25);
		DeleteLTextPlay.setBounds(23,429,262,60);
		DeleteLTextPlay.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextPlay);
		
		JLabel DeleteLWin = new JLabel("Win");
		DeleteLWin.setBounds(437, 113, 100, 67);
		DeleteLWin.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLWin.setForeground(new Color(255, 0, 0));
		DeleteLWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLWin);
		
		JTextField DeleteLTextWin = new JTextField(25);
		DeleteLTextWin.setBounds(353,170,267,60);
		DeleteLTextWin.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextWin);
		
		JLabel DeleteLDraw = new JLabel("Draw");
		DeleteLDraw.setBounds(437, 240, 120, 67);
		DeleteLDraw.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLDraw.setForeground(new Color(255, 0, 0));
		DeleteLDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLDraw);
		
		JTextField DeleteLTextDraw = new JTextField(25);
		DeleteLTextDraw.setBounds(353,299,267,60);
		DeleteLTextDraw.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextDraw);
		
		JLabel DeleteLLose = new JLabel("Lose");
		DeleteLLose.setBounds(437, 369, 100, 67);
		DeleteLLose.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLLose.setForeground(new Color(255, 0, 0));
		DeleteLLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLLose);
		
		JTextField DeleteLTextLose = new JTextField(25);
		DeleteLTextLose.setBounds(353,429,267,60);
		DeleteLTextLose.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextLose);
		
		JLabel DeleteLGD = new JLabel("GD");
		DeleteLGD.setBounds(100, 480, 100, 67);
		DeleteLGD.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLGD.setForeground(new Color(255, 0, 0));
		DeleteLGD.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLGD);
		
		JTextField DeleteLTextGD = new JTextField(25);
		DeleteLTextGD.setBounds(23,540,267,60);
		DeleteLTextGD.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextGD);
		
		JLabel DeleteLPTS = new JLabel("PTS");
		DeleteLPTS.setBounds(437, 480, 100, 67);
		DeleteLPTS.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteLPTS.setForeground(new Color(255, 0, 0));
		DeleteLPTS.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLPTS);
		
		JTextField DeleteLTextPTS = new JTextField(25);
		DeleteLTextPTS.setBounds(353,540,267,60);
		DeleteLTextPTS.setFont(new Font("Consolas",Font.BOLD,25));
		ToDeleteLeagueTable.add(DeleteLTextPTS);
		
		JButton DLCommit = new JButton("commit");
		DLCommit.setBounds(500, 103, 120, 23);
		DLCommit.setFont(new Font("Consolas", Font.BOLD, 25));
		ToDeleteLeagueTable.add(DLCommit);
		
		JButton DLeagueHome = new JButton("HOME");
		DLeagueHome.setFont(new Font("Consolas", Font.BOLD, 25));
		DLeagueHome.setBounds(512, 70, 91, 23);
		ToDeleteLeagueTable.add(DLeagueHome);
		
		DLeagueHome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDeleteLeagueTable.setVisible(false);
				FirstPage.setVisible(true);
			}
		});
		
		DeleteLeagueTable.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ToDelete.setVisible(false);
				ToDeleteLeagueTable.setVisible(true);
			}
		});
		
		DLCommit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String Ranking = DeleteLTextRanking.getText();
				String Play = DeleteLTextPlay.getText();
				String Team = DeleteLTextTeam.getText();
				String Win = DeleteLTextWin.getText();
				String Draw = DeleteLTextDraw.getText();
				String Lose = DeleteLTextLose.getText();
				String GD = DeleteLTextGD.getText();
				String PTS = DeleteLTextPTS.getText();
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					System.out.println("드라이브 연결");
					conn = DriverManager.getConnection("jdbc:mysql://localhost/Player?serverTimezone=UTC", "root",
							"1234");
					System.out.println("DB연결 성공");

					String query = "DELETE FROM League WHERE Ranking = ? and Team = ? "
							+ "and Play = ? and Win = ? and Draw = ? and Lose = ? "
							+ "and GD = ? and PTS = ?";

					statement = conn.prepareStatement(query);

					statement.setString(1, Ranking);
					statement.setString(2, Team);
					statement.setString(3, Play);
					statement.setString(4, Win);
					statement.setString(5, Draw);
					statement.setString(6, Lose);
					statement.setString(7, GD);
					statement.setString(8, PTS);
					
					int rowsInserted = statement.executeUpdate();

					if (rowsInserted > 0) {

						ImagePanel Deletecommitbutton = new ImagePanel(
								new ImageIcon("./Image/Chelsea1.png").getImage());
						Deletecommitbutton.setBounds(0, 0, 673, 673);
						frame.getContentPane().add(Deletecommitbutton);
						Deletecommitbutton.setLayout(null);
						Deletecommitbutton.setVisible(false);

						JButton Home14 = new JButton("HOME");
						Home14.setBounds(512, 70, 91, 23);
						Home14.setFont(new Font("Consolas", Font.BOLD, 25));
						Deletecommitbutton.add(Home14);

						JLabel Deletealert = new JLabel("Complete");
						Deletealert.setForeground(Color.RED);
						Deletealert.setFont(new Font("Consolas", Font.BOLD, 60));
						Deletealert.setHorizontalAlignment(SwingConstants.CENTER);
						Deletealert.setBounds(95, 240, 481, 112);
						Deletecommitbutton.add(Deletealert);

						Home14.addActionListener(new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								Deletecommitbutton.setVisible(false);
								FirstPage.setVisible(true);
							}
						});

						ToDeleteLeagueTable.setVisible(false);
						Deletecommitbutton.setVisible(true);
					}

				} catch (ClassNotFoundException enfe) {
					enfe.printStackTrace();
				} catch (SQLException se) {
					se.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException se) {
						}
					}
					if (stmt != null) {
						try {
							stmt.close();
						} catch (SQLException se) {
						}
					}
					if (rs != null) {
						try {
							rs.close();
						} catch (SQLException se) {
						}
					}
				}
			}
		}); // Delete LeagueTable
				
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

class ImagePanel extends JPanel {
	private Image image;

	public ImagePanel(Image image) {
		this.image = image;

		setSize(new Dimension(image.getWidth(null), image.getHeight(null)));
		setPreferredSize(new Dimension(image.getWidth(null), image.getHeight(null)));
		setLayout(null);
	}

	public void paintComponent(Graphics g) {
		g.drawImage(image, 0, 0, null);
	}
}